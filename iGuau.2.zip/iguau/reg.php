<?php


$link = mysql_connect("sql202.byethost16.com","b16_17493364","hackforgood2016") or die("No se encuentra el servidor ");
$Categoria=$_POST['categoria'];
switch ($Categoria) {
    case "comercios":
        $resul="b16_17493364_comercios";
        break;
    case "tien":
        $resul="b16_17493364_tien";
        break;
    case "hotel":
        $resul="b16_17493364_hotel";
        break;
    case "hosteleria":
        $resul="b16_17493364_hosteleria";
        break;
    case "aso":
       $resul="b16_17493364_aso";
        break;
    case "vete":
        $resul="b16_17493364_vete";
        break;
    case "trans":
       $resul="b16_17493364_trans";
        break;
    case "ocio":
        $resul="b16_17493364_ocio";
        break;

}
$db = mysql_select_db($resul,$link) or die("Error de conexion");

$dir=$_POST['dir'];
$lon=$_POST['lon'];
$lat=$_POST['lat'];
mysql_query("INSERT INTO $Categoria VALUES (' ','$dir','$lat','$lon')",$link) or die("error de envio");


header('Location: index.html');
?>